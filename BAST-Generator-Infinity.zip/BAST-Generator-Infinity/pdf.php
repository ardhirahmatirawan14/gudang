<?php
session_start();
date_default_timezone_set('Asia/Jakarta');

if (empty($_SESSION['bast_logged_in'])) {
    header('Location: login.php');
    exit;
}

$autoload = __DIR__ . '/vendor/autoload.php';

if (!is_file($autoload)) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Dompdf belum terpasang. Jalankan Composer di folder BAST-Generator-Sederhana.');
}

require_once $autoload;

$id = trim((string) ($_GET['id'] ?? ''));
$dataPath = __DIR__ . '/data/documents.json';
$raw = is_file($dataPath) ? file_get_contents($dataPath) : false;
$documents = is_string($raw) ? json_decode($raw, true) : null;
$document = null;

if (is_array($documents)) {
    foreach ($documents as $item) {
        if (is_array($item) && (string) ($item['id'] ?? '') === $id) {
            $document = $item;
            break;
        }
    }
}

if ($id === '' || $document === null) {
    http_response_code(404);
    exit('Dokumen BAST tidak ditemukan.');
}

$e = static fn ($value): string => htmlspecialchars(
    (string) ($value ?? ''),
    ENT_QUOTES | ENT_SUBSTITUTE,
    'UTF-8'
);

$date = new DateTimeImmutable(
    (string) ($document['bast_date'] ?? date('Y-m-d')) . ' 12:00:00'
);

$days = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu',
];

$months = [
    1 => 'Januari', 'Februari', 'Maret', 'April',
    'Mei', 'Juni', 'Juli', 'Agustus',
    'September', 'Oktober', 'November', 'Desember'
];

$dateText = ($days[$date->format('l')] ?? $date->format('l'))
    . ' ' . $date->format('d')
    . ' ' . $months[(int) $date->format('n')]
    . ' ' . $date->format('Y');

$backgroundPath = __DIR__ . '/assets/bast/latar-belakang.png';

if (!is_file($backgroundPath)) {
    http_response_code(500);
    exit('Gambar latar tidak ditemukan.');
}

$background = 'data:image/png;base64,'
    . base64_encode(file_get_contents($backgroundPath));

$p1 = $document['party_one'] ?? [];
$p2 = $document['party_two'] ?? [];
$sig = $document['signatures'] ?? [];
$materials = $document['materials'] ?? [];
$number = (string) ($document['bast_number'] ?? 'BAST');

$rows = '';

foreach ($materials as $i => $m) {
    $rows .= '<tr>'
        . '<td>' . $e($m['no'] ?? ($i + 1)) . '</td>'
        . '<td>' . $e($m['code'] ?? '') . '</td>'
        . '<td>' . $e($m['name'] ?? '') . '</td>'
        . '<td>' . $e($m['qty'] ?? '') . '</td>'
        . '<td>' . $e($m['sn'] ?? '') . '</td>'
        . '<td>' . $e($m['note'] ?? '') . '</td>'
        . '</tr>';
}

$html = '<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<style>
@page {
    size: A4 portrait;
    margin: 0;
}
* {
    box-sizing: border-box;
}
html, body {
    margin: 0;
    padding: 0;
    width: 210mm;
    font-family: Arial, Helvetica, sans-serif;
    color: #000;
    font-size: 12pt;
    line-height: 1.3;
}
.page {
    position: relative;
    width: 210mm;
    height: 297mm;
    overflow: hidden;
    page-break-after: always;
}
.page:last-child {
    page-break-after: auto;
}
.background {
    position: absolute;
    top: 0;
    left: 0;
    width: 210mm;
    height: 297mm;
}
.content {
    position: relative;
}
.page-one {
    padding: 42mm 17mm 25mm;
}
.title {
    text-align: center;
    font-weight: bold;
    text-decoration: underline;
    margin-bottom: 1mm;
}
.number {
    text-align: center;
    font-weight: bold;
    margin: 0 0 6mm;
}
.opening, .body-text {
    text-align: justify;
}
.opening {
    margin-bottom: 5mm;
}
.party {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 4mm;
}
.party td {
    border: none;
    padding: 1mm 0;
    vertical-align: top;
}
.party .label {
    width: 31mm;
}
.party .colon {
    width: 5mm;
    text-align: center;
}
.bold-row td {
    font-weight: bold;
}
.section-gap td {
    padding-top: 4mm;
}
.body-text {
    margin: 3mm 0;
}
.location-date {
    text-align: right;
    margin-top: 8mm;
    margin-bottom: 7mm;
}
.signature-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}
.signature-table td {
    width: 33.333%;
    text-align: center;
    vertical-align: top;
    border: none;
}
.signature-space {
    height: 25mm;
}
.signature-name {
    overflow-wrap: anywhere;
}
.page-two {
    padding: 39mm 14mm 18mm;
}
.attachment-title {
    font-weight: bold;
    margin-bottom: 5mm;
}
.material-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    font-size: 12pt;
}
.material-table th,
.material-table td {
    border: 1px solid #000;
    padding: 1.5mm 1.2mm;
    vertical-align: middle;
    overflow-wrap: anywhere;
}
.material-table th {
    text-align: center;
}
.material-table td:nth-child(1),
.material-table td:nth-child(4) {
    text-align: center;
}
.c-no { width: 9%; }
.c-code { width: 19%; }
.c-name { width: 28%; }
.c-qty { width: 9%; }
.c-sn { width: 19%; }
.c-note { width: 16%; }
</style>
</head>
<body>

<div class="page">
<img class="background" src="' . $background . '">
<div class="content page-one">

<div class="title">BERITA ACARA SERAH TERIMA PERANGKAT</div>
<div class="number">' . $e($number) . '</div>

<div class="opening">Pada hari ini, ' . $e($dateText) . '.
Yang bertanda tangan di bawah ini yaitu:</div>

<table class="party">
<tr class="bold-row">
<td class="label">Pihak Pertama</td>
<td class="colon">:</td>
<td>' . $e($p1['company'] ?? '') . '</td>
</tr>
<tr>
<td class="label">Diwakili oleh</td>
<td class="colon">:</td>
<td>' . $e($p1['name'] ?? '') . '</td>
</tr>
<tr>
<td class="label">Jabatan</td>
<td class="colon">:</td>
<td>' . $e($p1['position'] ?? '') . '</td>
</tr>
<tr class="section-gap"><td colspan="3"></td></tr>
<tr class="bold-row">
<td class="label">Pihak Kedua</td>
<td class="colon">:</td>
<td>' . $e($p2['company'] ?? '') . '</td>
</tr>
<tr>
<td class="label">Diwakili oleh</td>
<td class="colon">:</td>
<td>' . $e($p2['name'] ?? '') . '</td>
</tr>
<tr>
<td class="label">Jabatan</td>
<td class="colon">:</td>
<td>' . $e($p2['position'] ?? '') . '</td>
</tr>
</table>

<div class="body-text">
Menyatakan bahwa kedua belah pihak telah melakukan serah terima
material perangkat yang diserah terimakan dari PIHAK PERTAMA
kepada PIHAK KEDUA, dengan rincian material pada lampiran
dihalaman berikut.
</div>

<div class="body-text">
Apabila selama dalam masa pemakaian yang akan dilakukan PIHAK KEDUA terjadi
kerusakan dan kehilangan maka hal tersebut akan menjadi tanggung jawab
PIHAK KEDUA. Demikian berita acara serah terima ini dibuat dengan
sebenar-benarnya sehingga bagi pihak bersangkutan yaitu PIHAK PERTAMA dan PIHAK KEDUA dapat
menggunakan sebagaimana mestinya.
</div>

<div class="location-date">
Palangka Raya, ' . $e($date->format('d') . ' ' . $months[(int) $date->format('n')] . ' ' . $date->format('Y')) . '
</div>

<table class="signature-table">
<tr>
<td>Security,<div class="signature-space"></div>
<div class="signature-name">(' . $e($sig['security'] ?? '') . ')</div></td>
<td>Yang Menerima,<div class="signature-space"></div>
<div class="signature-name">(' . $e($sig['receiver'] ?? '') . ')</div></td>
<td>Yang Menyerahkan,<div class="signature-space"></div>
<div class="signature-name">(' . $e($sig['sender'] ?? '') . ')</div></td>
</tr>
</table>

</div>
</div>

<div class="page">
<img class="background" src="' . $background . '">
<div class="content page-two">
<div class="attachment-title">Lampiran</div>
<table class="material-table">
<thead><tr>
<th class="c-no">No</th>
<th class="c-code">KODE MATERIAL</th>
<th class="c-name">NAMA BARANG</th>
<th class="c-qty">QTY</th>
<th class="c-sn">SN</th>
<th class="c-note">KET</th>
</tr></thead>
<tbody>' . $rows . '</tbody>
</table>
</div>
</div>

</body>
</html>';

$options = new \Dompdf\Options();
$options->set('defaultFont', 'Arial');
$options->set('isRemoteEnabled', false);
$options->set('chroot', __DIR__);

$pdf = new \Dompdf\Dompdf($options);
$pdf->loadHtml($html, 'UTF-8');
$pdf->setPaper('A4', 'portrait');
$pdf->render();

$filename = preg_replace('/[^A-Za-z0-9._-]/', '-', $number) ?: 'BAST';

$pdf->stream($filename . '.pdf', [
    'Attachment' => false
]);
exit;

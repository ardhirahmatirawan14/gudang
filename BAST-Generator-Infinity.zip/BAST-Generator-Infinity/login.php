<?php
declare(strict_types=1);

session_start();
$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Jakarta');

if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: login.php');
    exit;
}

if (!empty($_SESSION['bast_logged_in'])) {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['login_csrf'])) {
    $_SESSION['login_csrf'] = bin2hex(random_bytes(24));
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string) ($_POST['csrf'] ?? '');
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if (!hash_equals((string) $_SESSION['login_csrf'], $token)) {
        $error = 'Sesi login kedaluwarsa. Silakan coba lagi.';
    } elseif (hash_equals((string) ($config['username'] ?? 'admin'), $username) && hash_equals((string) ($config['password'] ?? ''), $password)) {
        session_regenerate_id(true);
        $_SESSION['bast_logged_in'] = true;
        $_SESSION['login_csrf'] = bin2hex(random_bytes(24));
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login · BAST Generator</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="login-page">
    <main class="login-card">
        <div class="brand-mark">BA</div>
        <p class="eyebrow">DOKUMEN SERAH TERIMA PERANGKAT</p>
        <h1>BAST Generator</h1>
        <p class="muted">Masuk untuk mengelola dokumen BAST.</p>
        <?php if ($error !== ''): ?><div class="alert alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
        <form method="post" autocomplete="on">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars((string) $_SESSION['login_csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <label for="username">Username</label>
            <input id="username" name="username" type="text" autocomplete="username" value="admin" required autofocus>
            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
            <button class="btn btn-primary btn-block" type="submit">Masuk</button>
        </form>
        <p class="login-help">Gunakan username dan password yang diatur oleh pengelola aplikasi.</p>
    </main>
</body>
</html>

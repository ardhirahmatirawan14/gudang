<?php
declare(strict_types=1);

session_start();
$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Jakarta');

const BAST_DATA_FILE = __DIR__ . '/data/documents.json';
const BAST_LOCK_FILE = __DIR__ . '/data/documents.lock';

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function readDocuments(): array
{
    if (!is_file(BAST_DATA_FILE)) {
        return [];
    }
    $raw = file_get_contents(BAST_DATA_FILE);
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $data = json_decode($raw, true);
    return is_array($data) ? array_values(array_filter($data, 'is_array')) : [];
}

function writeDocuments(array $documents): void
{
    $json = json_encode(array_values($documents), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Data BAST tidak dapat diubah menjadi JSON.');
    }
    $temporary = BAST_DATA_FILE . '.tmp';
    if (file_put_contents($temporary, $json, LOCK_EX) === false) {
        throw new RuntimeException('Gagal menyimpan data. Periksa izin tulis folder data.');
    }
    if (!rename($temporary, BAST_DATA_FILE)) {
        @unlink($temporary);
        throw new RuntimeException('Gagal memperbarui penyimpanan data BAST.');
    }
}

function mutateDocuments(callable $callback): mixed
{
    $lock = fopen(BAST_LOCK_FILE, 'c+');
    if ($lock === false) {
        throw new RuntimeException('Gagal membuka pengunci penyimpanan.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Gagal mengunci penyimpanan.');
        }
        $documents = readDocuments();
        $result = $callback($documents);
        writeDocuments($documents);
        return $result;
    } finally {
        @flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function findDocument(array $documents, string $id): ?array
{
    foreach ($documents as $document) {
        if ((string) ($document['id'] ?? '') === $id) {
            return $document;
        }
    }
    return null;
}

function formatNumber(string $date, int $sequence): string
{
    $stamp = strtotime($date . ' 12:00:00');
    if ($stamp === false) {
        throw new InvalidArgumentException('Tanggal BAST tidak valid.');
    }
    return date('dm', $stamp) . str_pad((string) $sequence, 2, '0', STR_PAD_LEFT) . '/BAST/ICON+KLM/' . date('Y', $stamp);
}

function maxLocalSequence(array $documents, string $date): int
{
    $maximum = 0;
    foreach ($documents as $document) {
        if ((string) ($document['bast_date'] ?? '') !== $date) {
            continue;
        }
        $sequence = (int) ($document['sequence'] ?? 0);
        if ($sequence > 0) {
            $maximum = max($maximum, $sequence);
            continue;
        }
        $number = (string) ($document['bast_number'] ?? '');
        if (preg_match('~^\d{4}(\d+)/BAST/ICON\+KLM/\d{4}$~', $number, $matches)) {
            $maximum = max($maximum, (int) $matches[1]);
        }
    }
    return $maximum;
}

/**
 * Menandatangani payload untuk dikirim browser ke Apps Script lewat JSONP.
 * Secret tetap berada di PHP dan tidak dikirim ke browser.
 */
function signedGoogleBridge(array $config, array $payload): ?array
{
    $url = trim((string) ($config['google_sheets_url'] ?? ''));
    $secret = (string) ($config['google_sheets_secret'] ?? '');
    if ($url === '' || $secret === '') {
        return null;
    }

    $request = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($request === false) {
        throw new RuntimeException('Data Google Sheets tidak dapat disiapkan.');
    }

    return [
        'request' => $request,
        'signature' => hash_hmac('sha256', $request, $secret),
    ];
}

function googleDocumentPayload(array $document): array
{
    return [
        'action' => 'upsert',
        'document' => [
            'bast_number' => $document['bast_number'] ?? '',
            'party_one' => $document['party_one'] ?? [],
            'party_two' => $document['party_two'] ?? [],
            'signatures' => $document['signatures'] ?? [],
            'materials' => array_values($document['materials'] ?? []),
        ],
    ];
}

function cleanText(mixed $value, string $label, int $maxLength = 500): string
{
    $text = trim((string) $value);
    if ($text === '') {
        throw new InvalidArgumentException($label . ' wajib diisi.');
    }
    if (function_exists('mb_strlen') && mb_strlen($text) > $maxLength) {
        throw new InvalidArgumentException($label . ' terlalu panjang.');
    }
    return $text;
}

function isValidDate(string $date): bool
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return false;
    }
    [$year, $month, $day] = array_map('intval', explode('-', $date));
    return checkdate($month, $day, $year);
}

/* API requests are handled by this same small PHP file; no Laravel or Composer needed. */
if (isset($_GET['api'])) {
    if (empty($_SESSION['bast_logged_in'])) {
        jsonResponse(['ok' => false, 'message' => 'Sesi login berakhir. Silakan login kembali.'], 401);
    }

    $action = (string) $_GET['api'];
    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

    try {
        if ($action === 'prepare-sequence' && $method === 'GET') {
            $date = trim((string) ($_GET['date'] ?? ''));
            if (!isValidDate($date)) {
                throw new InvalidArgumentException('Tanggal untuk nomor BAST tidak valid.');
            }
            $bridge = signedGoogleBridge($config, ['action' => 'maxSequence', 'date' => $date]);
            if ($bridge === null) {
                throw new RuntimeException('Google Sheets belum dikonfigurasi di config.php.');
            }
            jsonResponse(['ok' => true, 'bridge' => $bridge]);
        }
        if ($action === 'list' && $method === 'GET') {
            $documents = readDocuments();
            usort($documents, static fn(array $a, array $b): int => strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? '')));
            jsonResponse(['ok' => true, 'documents' => $documents]);
        }

        if ($action === 'save' && $method === 'POST') {
            $input = json_decode((string) file_get_contents('php://input'), true);
            if (!is_array($input)) {
                jsonResponse(['ok' => false, 'message' => 'Data formulir tidak valid.'], 400);
            }

            $dateMode = (($input['date_mode'] ?? 'auto') === 'manual') ? 'manual' : 'auto';
            $date = $dateMode === 'auto' ? date('Y-m-d') : trim((string) ($input['bast_date'] ?? ''));
            if (!isValidDate($date)) {
                throw new InvalidArgumentException('Tanggal BAST tidak valid.');
            }
            $numberMode = (($input['number_mode'] ?? 'auto') === 'manual') ? 'manual' : 'auto';
            $manualNumber = trim((string) ($input['bast_number'] ?? ''));
            if ($numberMode === 'manual' && $manualNumber === '') {
                throw new InvalidArgumentException('Nomor BAST manual wajib diisi.');
            }

            $partyOne = [
                'company' => cleanText($input['party_one']['company'] ?? '', 'Pihak Pertama'),
                'name' => cleanText($input['party_one']['name'] ?? '', 'Nama pihak pertama'),
                'position' => cleanText($input['party_one']['position'] ?? '', 'Jabatan pihak pertama'),
            ];
            $partyTwo = [
                'company' => cleanText($input['party_two']['company'] ?? '', 'Pihak Kedua'),
                'name' => cleanText($input['party_two']['name'] ?? '', 'Nama pihak kedua'),
                'position' => cleanText($input['party_two']['position'] ?? '', 'Jabatan pihak kedua'),
            ];
            $signatures = [
                'security' => cleanText($input['signatures']['security'] ?? '', 'Nama Security'),
                'receiver' => cleanText($input['signatures']['receiver'] ?? '', 'Nama penerima'),
                'sender' => cleanText($input['signatures']['sender'] ?? '', 'Nama penyerah'),
            ];
            $rawMaterials = $input['materials'] ?? [];
            if (!is_array($rawMaterials) || count($rawMaterials) < 1) {
                throw new InvalidArgumentException('Minimal satu baris material wajib diisi.');
            }
            $materials = [];
            foreach (array_values($rawMaterials) as $index => $material) {
                if (!is_array($material)) {
                    continue;
                }
                $materials[] = [
                    'no' => trim((string) ($material['no'] ?? ($index + 1))) ?: (string) ($index + 1),
                    'code' => cleanText($material['code'] ?? '', 'Kode material baris ' . ($index + 1)),
                    'name' => cleanText($material['name'] ?? '', 'Nama barang baris ' . ($index + 1)),
                    'qty' => cleanText($material['qty'] ?? '', 'QTY baris ' . ($index + 1)),
                    'sn' => cleanText($material['sn'] ?? '', 'SN baris ' . ($index + 1)),
                    'note' => cleanText($material['note'] ?? '', 'Keterangan baris ' . ($index + 1)),
                ];
            }
            if (!$materials) {
                throw new InvalidArgumentException('Minimal satu baris material wajib diisi.');
            }

            $id = trim((string) ($input['id'] ?? ''));
            $before = readDocuments();
            $existing = $id !== '' ? findDocument($before, $id) : null;
            if ($id !== '' && $existing === null) {
                jsonResponse(['ok' => false, 'message' => 'Dokumen BAST yang diedit tidak ditemukan. Muat ulang riwayat.'], 404);
            }

            $sheetConfigured = trim((string) ($config['google_sheets_url'] ?? '')) !== '' && trim((string) ($config['google_sheets_secret'] ?? '')) !== '';
            $externalMax = isset($input['external_max_sequence']) && is_numeric($input['external_max_sequence'])
                ? max(0, (int) $input['external_max_sequence'])
                : null;

            $saved = mutateDocuments(static function (&$documents) use ($id, $existing, $date, $dateMode, $numberMode, $manualNumber, $externalMax, $partyOne, $partyTwo, $signatures, $materials): array {
                $now = date(DATE_ATOM);
                if ($id !== '') {
                    $index = null;
                    foreach ($documents as $i => $item) {
                        if ((string) ($item['id'] ?? '') === $id) {
                            $index = $i;
                            break;
                        }
                    }
                    if ($index === null) {
                        throw new RuntimeException('Dokumen BAST tidak ditemukan. Muat ulang halaman.');
                    }
                    $old = $documents[$index];
                    $oldDate = (string) ($old['bast_date'] ?? $date);
                    if ($date === $oldDate) {
                        $sequence = max(1, (int) ($old['sequence'] ?? 1));
                    } else {
                        $sequence = max(maxLocalSequence($documents, $date), max(0, (int) ($externalMax ?? 0))) + 1;
                    }
                    $number = $numberMode === 'manual' ? $manualNumber : formatNumber($date, $sequence);
                    $document = array_merge($old, [
                        'bast_date' => $date,
                        'date_mode' => $dateMode,
                        'number_mode' => $numberMode,
                        'bast_number' => $number,
                        'sequence' => $sequence,
                        'party_one' => $partyOne,
                        'party_two' => $partyTwo,
                        'signatures' => $signatures,
                        'materials' => $materials,
                        'updated_at' => $now,
                    ]);
                    $documents[$index] = $document;
                    return $document;
                }

                $sequence = max(maxLocalSequence($documents, $date), max(0, (int) ($externalMax ?? 0))) + 1;
                $number = $numberMode === 'manual' ? $manualNumber : formatNumber($date, $sequence);
                $document = [
                    'id' => bin2hex(random_bytes(16)),
                    'bast_number' => $number,
                    'bast_date' => $date,
                    'date_mode' => $dateMode,
                    'number_mode' => $numberMode,
                    'sequence' => $sequence,
                    'party_one' => $partyOne,
                    'party_two' => $partyTwo,
                    'signatures' => $signatures,
                    'materials' => $materials,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
                array_unshift($documents, $document);
                return $document;
            });

            $bridge = $sheetConfigured ? signedGoogleBridge($config, googleDocumentPayload($saved)) : null;
            $syncStatus = $bridge === null ? 'not_configured' : 'client_required';
            jsonResponse(['ok' => true, 'document' => $saved, 'sync_status' => $syncStatus, 'bridge' => $bridge]);
        }

        if ($action === 'sync' && $method === 'POST') {
            $id = trim((string) ($_GET['id'] ?? ''));
            $document = findDocument(readDocuments(), $id);
            if ($document === null) {
                jsonResponse(['ok' => false, 'message' => 'Dokumen tidak ditemukan.'], 404);
            }
            $bridge = signedGoogleBridge($config, googleDocumentPayload($document));
            if ($bridge === null) {
                throw new RuntimeException('Google Sheets belum dikonfigurasi di config.php.');
            }
            jsonResponse([
                'ok' => true,
                'message' => 'Dokumen siap disinkronkan ke Google Sheets.',
                'document' => $document,
                'bridge' => $bridge,
            ]);
        }

        jsonResponse(['ok' => false, 'message' => 'Permintaan tidak dikenali.'], 400);
    } catch (InvalidArgumentException $error) {
        jsonResponse(['ok' => false, 'message' => $error->getMessage()], 422);
    } catch (Throwable $error) {
        jsonResponse(['ok' => false, 'message' => $error->getMessage() ?: 'Terjadi kesalahan pada server.'], 500);
    }
}

if (empty($_SESSION['bast_logged_in'])) {
    header('Location: login.php');
    exit;
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BAST Generator</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="app-shell" id="app-shell">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-mark">BA</div>
            <div><h1>BAST Generator</h1><p>SERAH TERIMA PERANGKAT</p></div>
        </div>
        <nav class="nav-menu" aria-label="Navigasi utama">
            <button type="button" class="nav-link active" data-view="history">Riwayat BAST</button>
            <button type="button" class="nav-link" data-view="form">+ Tambah BAST</button>
        </nav>
        <div class="sidebar-note">Data dokumen tersimpan pada hosting. Cetak BAST melalui fitur cetak browser dan pilih “Save as PDF”.</div>
        <a class="logout-link" href="login.php?logout=1">Keluar</a>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div><span class="eyebrow">DOKUMEN INTERNAL</span><h2 id="top-title">Riwayat BAST</h2></div>
            <span class="today-label" id="today-label"></span>
        </header>
        <div id="alert-region" aria-live="polite"></div>

        <section id="history-view" class="view-section">
            <div class="page-head">
                <div><h3>Riwayat BAST</h3><p>Periksa, edit, sinkronkan, atau cetak dokumen yang sudah dibuat.</p></div>
                <button type="button" class="btn btn-primary" id="new-bast-button">+ Tambah BAST</button>
            </div>
            <div class="stat-card"><span>Total dokumen</span><strong id="total-count">0</strong></div>
            <div class="card">
                <div class="toolbar"><label class="search-label" for="history-search">Cari nomor atau nama</label><input id="history-search" type="search" placeholder="Ketik nomor BAST / nama pihak..."></div>
                <div class="table-wrap">
                    <table class="history-table">
                        <thead><tr><th>No. BAST</th><th>Tanggal</th><th>Pihak Pertama</th><th>Pihak Kedua</th><th>Material</th><th>Aksi</th></tr></thead>
                        <tbody id="history-body"><tr><td colspan="6" class="empty">Memuat riwayat...</td></tr></tbody>
                    </table>
                </div>
            </div>
        </section>

        <section id="form-view" class="view-section" hidden>
            <div class="page-head"><div><h3 id="form-title">Tambah BAST</h3><p>Isi data serah terima dan rincian material.</p></div></div>
            <form id="bast-form" class="card form-card">
                <input type="hidden" id="document-id">
                <section class="form-section">
                    <h4>Informasi BAST</h4>
                    <div class="form-grid">
                        <div class="field"><label for="date-mode">Tanggal</label><div class="mode-row"><select id="date-mode"><option value="auto">Otomatis</option><option value="manual">Manual</option></select><input id="bast-date" type="date" required></div><small id="date-help">Mode otomatis memakai tanggal hari ini.</small></div>
                        <div class="field"><label for="number-mode">Nomor BAST</label><div class="mode-row"><select id="number-mode"><option value="auto">Otomatis</option><option value="manual">Manual</option></select><input id="bast-number" type="text" placeholder="Ditentukan saat disimpan" maxlength="100" required></div><small id="number-help">Nomor otomatis dihitung ketika disimpan.</small></div>
                    </div>
                </section>
                <section class="form-section">
                    <h4>Pihak Pertama</h4>
                    <div class="form-grid">
                        <div class="field"><label for="p1-company">Perusahaan</label><input id="p1-company" required placeholder="PLN Icon Plus"></div>
                        <div class="field"><label for="p1-name">Nama 1</label><input id="p1-name" required></div>
                        <div class="field"><label for="p1-position">Jabatan 1</label><input id="p1-position" required></div>
                    </div>
                </section>
                <section class="form-section">
                    <h4>Pihak Kedua</h4>
                    <div class="form-grid">
                        <div class="field"><label for="p2-company">Perusahaan</label><input id="p2-company" required placeholder="PLN Icon Plus"></div>
                        <div class="field"><label for="p2-name">Nama 2</label><input id="p2-name" required></div>
                        <div class="field"><label for="p2-position">Jabatan 2</label><input id="p2-position" required></div>
                    </div>
                </section>
                <section class="form-section">
                    <h4>Tanda Tangan</h4>
                    <div class="form-grid">
                        <div class="field"><label for="signature-security">Security</label><input id="signature-security" required></div>
                        <div class="field"><label for="signature-receiver">Yang Menerima</label><input id="signature-receiver" required></div>
                        <div class="field"><label for="signature-sender">Yang Menyerahkan</label><input id="signature-sender" required></div>
                    </div>
                </section>
                <section class="form-section">
                    <div class="section-heading"><div><h4>Rincian Material</h4><p>Minimal satu baris material.</p></div><button type="button" class="btn btn-light" id="add-material">+ Tambah Baris</button></div>
                    <div class="table-wrap"><table class="material-form-table"><thead><tr><th>No</th><th>KODE MATERIAL</th><th>NAMA BARANG</th><th>QTY</th><th>SN</th><th>KET</th><th></th></tr></thead><tbody id="material-body"></tbody></table></div>
                </section>
                <div class="form-actions"><button type="button" class="btn btn-light" id="cancel-form">Batal</button><button type="submit" class="btn btn-primary" id="save-button">Simpan BAST</button></div>
            </form>
        </section>

        <section id="detail-view" class="view-section" hidden>
            <div class="page-head"><div><h3>Detail BAST</h3><p>Periksa data dokumen sebelum mencetak.</p></div><div class="actions"><button class="btn btn-light" id="back-history">Kembali</button><button class="btn btn-light" id="edit-document">Edit</button><button class="btn btn-primary" id="sync-document">Sinkronkan</button><button class="btn btn-primary" id="print-document">Cetak PDF</button></div></div>
            <div id="detail-content"></div>
        </section>
    </main>
</div>
<div id="print-area" aria-hidden="true"></div>
<script>
window.BAST_GOOGLE_SCRIPT_URL = <?= json_encode((string) ($config['google_sheets_url'] ?? ''), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
</script>
<script src="app.js" defer></script>
</body>
</html>

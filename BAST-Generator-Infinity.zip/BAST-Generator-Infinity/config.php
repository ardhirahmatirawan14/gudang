<?php
declare(strict_types=1);

return [
    'timezone' => 'Asia/Jakarta',

    'username' => 'admin',
    'password' => '123',

    'google_sheets_url' => 'https://script.google.com/macros/s/AKfycbxsMjIEmsXUPGsIjufzqZXrV4eTtc5V1tTSO2wYbYczI4MLd10ejq465q1e4hf6HCDf5w/exec',

    'google_sheets_secret' => 'BAST-ICON-KLM-2026',
];
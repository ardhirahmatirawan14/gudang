
(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = { documents: [], currentDocument: null, returnAfterCancel: 'history' };

  const views = {
    history: $('#history-view'),
    form: $('#form-view'),
    detail: $('#detail-view'),
  };

  const api = async (action, options = {}) => {
    const response = await fetch(`index.php?api=${encodeURIComponent(action)}${options.query || ''}`, {
      method: options.method || 'GET',
      headers: options.body ? { 'Content-Type': 'application/json' } : {},
      body: options.body ? JSON.stringify(options.body) : undefined,
      credentials: 'same-origin',
      cache: 'no-store',
    });
    let result;
    try { result = await response.json(); }
    catch { throw new Error('Server mengembalikan respons yang tidak bisa dibaca.'); }
    if (!response.ok || result.ok !== true) throw new Error(result.message || 'Permintaan gagal.');
    return result;
  };

  // Kirim request bertanda tangan langsung dari browser ke Apps Script.
  // Dengan demikian, PHP hosting tidak perlu membuat koneksi keluar ke Google.
  const googleSheetsJsonp = (bridge) => new Promise((resolve, reject) => {
    const endpoint = String(window.BAST_GOOGLE_SCRIPT_URL || '').trim();
    if (!endpoint) {
      reject(new Error('URL Google Apps Script belum dikonfigurasi.'));
      return;
    }
    if (!bridge || typeof bridge.request !== 'string' || typeof bridge.signature !== 'string') {
      reject(new Error('Data permintaan Google Sheets tidak valid.'));
      return;
    }

    const callbackName = `bastJsonp_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
    const scriptId = callbackName + '_script';
    const separator = endpoint.includes('?') ? '&' : '?';
    const src = endpoint + separator + new URLSearchParams({
      request: bridge.request,
      signature: bridge.signature,
      callback: callbackName,
      t: String(Date.now()),
    }).toString();

    // URL yang sangat panjang bisa ditolak oleh server/proxy. Beri pesan yang jelas.
    if (src.length > 7500) {
      reject(new Error('Data BAST terlalu besar untuk metode sinkronisasi ini. Kurangi jumlah/baris material lalu coba lagi.'));
      return;
    }

    const script = document.createElement('script');
    script.id = scriptId;
    script.async = true;
    let finished = false;
    const cleanup = () => {
      try { delete window[callbackName]; } catch (_) { window[callbackName] = undefined; }
      script.remove();
    };
    const timeout = window.setTimeout(() => {
      if (finished) return;
      finished = true;
      cleanup();
      reject(new Error('Google Apps Script tidak merespons dalam 20 detik.'));
    }, 20000);

    window[callbackName] = (data) => {
      if (finished) return;
      finished = true;
      window.clearTimeout(timeout);
      cleanup();
      if (!data || data.ok !== true) {
        reject(new Error(data?.message || 'Google Sheets menolak permintaan.'));
        return;
      }
      resolve(data);
    };
    script.onerror = () => {
      if (finished) return;
      finished = true;
      window.clearTimeout(timeout);
      cleanup();
      reject(new Error('Browser tidak dapat memuat Google Apps Script.'));
    };
    script.src = src;
    document.body.appendChild(script);
  });

  const getGoogleMaxSequence = async (date) => {
    const prepared = await api('prepare-sequence', { query: `&date=${encodeURIComponent(date)}` });
    const result = await googleSheetsJsonp(prepared.bridge);
    return Math.max(0, Number(result.max_sequence) || 0);
  };

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;',
  })[char]);

  const localToday = () => {
    const date = new Date();
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };

  const formatDate = (dateString, includeDay = false) => {
    if (!dateString) return '-';
    const date = new Date(`${dateString}T12:00:00`);
    if (Number.isNaN(date.getTime())) return dateString;
    const weekdays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    const day = `${String(date.getDate()).padStart(2, '0')} ${months[date.getMonth()]} ${date.getFullYear()}`;
    return includeDay ? `${weekdays[date.getDay()]} ${day}` : day;
  };

  const formatDateTime = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '-';
    return date.toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' });
  };

  const showAlert = (message, type = 'success') => {
    const region = $('#alert-region');
    region.innerHTML = `<div class="alert alert-${type}">${escapeHtml(message)}</div>`;
    region.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    window.setTimeout(() => { region.innerHTML = ''; }, 6500);
  };

  const setView = (viewName) => {
    Object.entries(views).forEach(([name, element]) => { element.hidden = name !== viewName; });
    $$('.nav-link').forEach((button) => button.classList.toggle('active', button.dataset.view === viewName));
    const titles = { history: 'Riwayat BAST', form: $('#document-id').value ? 'Edit BAST' : 'Tambah BAST', detail: 'Detail BAST' };
    $('#top-title').textContent = titles[viewName] || 'BAST Generator';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderHistory = () => {
    const search = ($('#history-search').value || '').trim().toLowerCase();
    const filtered = state.documents.filter((doc) => {
      const haystack = [doc.bast_number, doc.party_one?.name, doc.party_one?.company, doc.party_two?.name, doc.party_two?.company].join(' ').toLowerCase();
      return haystack.includes(search);
    });
    $('#total-count').textContent = String(state.documents.length);
    const body = $('#history-body');
    if (!filtered.length) {
      body.innerHTML = `<tr><td colspan="6" class="empty">${state.documents.length ? 'Tidak ada BAST yang cocok dengan pencarian.' : 'Belum ada BAST. Klik “Tambah BAST” untuk membuat dokumen.'}</td></tr>`;
      return;
    }
    body.innerHTML = filtered.map((doc) => `
      <tr>
        <td><strong>${escapeHtml(doc.bast_number)}</strong><small class="row-meta">Diubah ${escapeHtml(formatDateTime(doc.updated_at))}</small></td>
        <td>${escapeHtml(formatDate(doc.bast_date))}</td>
        <td>${escapeHtml(doc.party_one?.name || '')}</td>
        <td>${escapeHtml(doc.party_two?.name || '')}</td>
        <td><span class="pill">${(doc.materials || []).length} baris</span></td>
        <td><div class="actions compact"><button class="btn btn-light btn-small" data-action="detail" data-id="${escapeHtml(doc.id)}">Detail</button><button class="btn btn-light btn-small" data-action="edit" data-id="${escapeHtml(doc.id)}">Edit</button><button class="btn btn-primary btn-small" data-action="print" data-id="${escapeHtml(doc.id)}">Cetak</button></div></td>
      </tr>`).join('');
  };

  const refreshDocuments = async () => {
    const result = await api('list');
    state.documents = Array.isArray(result.documents) ? result.documents : [];
    renderHistory();
  };

  const addMaterialRow = (material = {}) => {
    const body = $('#material-body');
    const row = document.createElement('tr');
    row.className = 'material-row';
    const fields = [
      { key: 'no', label: 'No', value: material.no ?? String(body.children.length + 1), required: true },
      { key: 'code', label: 'Kode material', value: material.code ?? '', required: true },
      { key: 'name', label: 'Nama barang', value: material.name ?? '', required: true },
      { key: 'qty', label: 'QTY', value: material.qty ?? '', required: true },
      { key: 'sn', label: 'SN', value: material.sn ?? '', required: true },
      { key: 'note', label: 'Keterangan', value: material.note ?? '', required: true },
    ];
    row.innerHTML = fields.map((field) => `<td><input data-material="${field.key}" aria-label="${field.label}" value="${escapeHtml(field.value)}" ${field.required ? 'required' : ''} ${field.key === 'no' ? 'class="material-no"' : ''}></td>`).join('') + '<td class="row-actions"><button type="button" class="icon-btn" data-action="remove-row" aria-label="Hapus baris">×</button></td>';
    body.appendChild(row);
    renumberMaterials();
  };

  const renumberMaterials = () => {
    $$('.material-row', $('#material-body')).forEach((row, index) => {
      const no = $('[data-material="no"]', row);
      if (no && no.dataset.manualEdited !== '1') no.value = String(index + 1);
    });
  };

  const setDateMode = () => {
    const automatic = $('#date-mode').value === 'auto';
    const input = $('#bast-date');
    input.readOnly = automatic;
    if (automatic) input.value = localToday();
    $('#date-help').textContent = automatic ? 'Mode otomatis memakai tanggal hari ini.' : 'Pilih tanggal BAST secara manual.';
    updateAutoNumberMessage();
  };

  const setNumberMode = (keepManual = false) => {
    const automatic = $('#number-mode').value === 'auto';
    const input = $('#bast-number');
    input.readOnly = automatic;
    input.required = true;
    if (automatic) {
      input.value = 'Otomatis saat disimpan';
      $('#number-help').textContent = 'Nomor dihitung saat dokumen disimpan.';
    } else {
      if (!keepManual) input.value = '';
      $('#number-help').textContent = 'Isi nomor BAST sesuai format yang ditentukan.';
    }
  };

  const updateAutoNumberMessage = () => {
    if ($('#number-mode').value !== 'auto') return;
    $('#bast-number').value = 'Otomatis saat disimpan';
    $('#number-help').textContent = $('#date-mode').value === 'manual' && $('#bast-date').value !== localToday()
      ? 'Nomor otomatis akan dihitung berdasarkan tanggal manual saat disimpan.'
      : 'Nomor dihitung saat dokumen disimpan.';
  };

  const resetForm = () => {
    $('#bast-form').reset();
    $('#document-id').value = '';
    $('#form-title').textContent = 'Tambah BAST';
    $('#save-button').textContent = 'Simpan BAST';
    $('#date-mode').value = 'auto';
    $('#bast-date').value = localToday();
    $('#number-mode').value = 'auto';
    $('#material-body').innerHTML = '';
    addMaterialRow();
    setDateMode();
    setNumberMode(true);
  };

  const openNewForm = () => {
    state.returnAfterCancel = 'history';
    resetForm();
    setView('form');
  };

  const openEditForm = (doc, returnView) => {
    state.returnAfterCancel = returnView;
    resetForm();
    $('#document-id').value = doc.id;
    $('#form-title').textContent = 'Edit BAST';
    $('#save-button').textContent = 'Simpan Perubahan';
    $('#date-mode').value = doc.date_mode === 'auto' ? 'auto' : 'manual';
    $('#bast-date').value = doc.date_mode === 'auto' ? localToday() : (doc.bast_date || localToday());
    $('#number-mode').value = doc.number_mode || (formatNumberClient(doc.bast_date, doc.sequence) === doc.bast_number ? 'auto' : 'manual');
    $('#bast-number').value = doc.bast_number || '';
    $('#p1-company').value = doc.party_one?.company || '';
    $('#p1-name').value = doc.party_one?.name || '';
    $('#p1-position').value = doc.party_one?.position || '';
    $('#p2-company').value = doc.party_two?.company || '';
    $('#p2-name').value = doc.party_two?.name || '';
    $('#p2-position').value = doc.party_two?.position || '';
    $('#signature-security').value = doc.signatures?.security || '';
    $('#signature-receiver').value = doc.signatures?.receiver || '';
    $('#signature-sender').value = doc.signatures?.sender || '';
    $('#material-body').innerHTML = '';
    (doc.materials || []).forEach((material) => addMaterialRow(material));
    if (!doc.materials?.length) addMaterialRow();
    setDateMode();
    setNumberMode(true);
    if ($('#number-mode').value === 'manual') $('#bast-number').value = doc.bast_number || '';
    setView('form');
  };

  const formatNumberClient = (dateString, sequence) => {
    if (!dateString || !sequence) return '';
    return `${dateString.slice(8, 10)}${dateString.slice(5, 7)}${String(sequence).padStart(2, '0')}/BAST/ICON+KLM/${dateString.slice(0, 4)}`;
  };

  const renderDetail = (doc) => {
    state.currentDocument = doc;
    $('#detail-content').innerHTML = `
      <div class="number-card"><span>Nomor BAST</span><strong>${escapeHtml(doc.bast_number)}</strong><small>Tanggal ${escapeHtml(formatDate(doc.bast_date))}</small></div>
      <div class="detail-grid">
        <article class="detail-box"><h4>Pihak Pertama</h4><dl><dt>Perusahaan</dt><dd>${escapeHtml(doc.party_one?.company)}</dd><dt>Nama</dt><dd>${escapeHtml(doc.party_one?.name)}</dd><dt>Jabatan</dt><dd>${escapeHtml(doc.party_one?.position)}</dd></dl></article>
        <article class="detail-box"><h4>Pihak Kedua</h4><dl><dt>Perusahaan</dt><dd>${escapeHtml(doc.party_two?.company)}</dd><dt>Nama</dt><dd>${escapeHtml(doc.party_two?.name)}</dd><dt>Jabatan</dt><dd>${escapeHtml(doc.party_two?.position)}</dd></dl></article>
      </div>
      <article class="detail-box material-detail"><h4>Rincian Material</h4><div class="table-wrap"><table><thead><tr><th>No</th><th>KODE MATERIAL</th><th>NAMA BARANG</th><th>QTY</th><th>SN</th><th>KET</th></tr></thead><tbody>${(doc.materials || []).map((m, i) => `<tr><td>${escapeHtml(m.no || i + 1)}</td><td>${escapeHtml(m.code)}</td><td>${escapeHtml(m.name)}</td><td>${escapeHtml(m.qty)}</td><td>${escapeHtml(m.sn)}</td><td>${escapeHtml(m.note)}</td></tr>`).join('')}</tbody></table></div></article>
      <div class="signature-cards"><div><span>Security</span><strong>(${escapeHtml(doc.signatures?.security)})</strong></div><div><span>Yang Menerima</span><strong>(${escapeHtml(doc.signatures?.receiver)})</strong></div><div><span>Yang Menyerahkan</span><strong>(${escapeHtml(doc.signatures?.sender)})</strong></div></div>
      <p class="updated-note">Dibuat ${escapeHtml(formatDateTime(doc.created_at))} · Terakhir diubah ${escapeHtml(formatDateTime(doc.updated_at))}</p>`;
    setView('detail');
  };

  const openDetail = (doc) => { state.returnAfterCancel = 'history'; renderDetail(doc); };

  const buildPrintPages = (doc) => {
    const materials = (doc.materials || []).map((m, i) => `<tr><td>${escapeHtml(m.no || i + 1)}</td><td>${escapeHtml(m.code)}</td><td>${escapeHtml(m.name)}</td><td>${escapeHtml(m.qty)}</td><td>${escapeHtml(m.sn)}</td><td>${escapeHtml(m.note)}</td></tr>`).join('');
    const background = 'assets/bast/latar-belakang.png';
    $('#print-area').innerHTML = `
      <article class="paper print-page-1">
        <img class="paper-background" src="${background}" alt="">
        <div class="paper-content page-one-content">
          <h1 class="document-title">BERITA ACARA SERAH TERIMA PERANGKAT</h1>
          <p class="document-number">${escapeHtml(doc.bast_number)}</p>
          <p class="opening-text">Pada hari ini, ${escapeHtml(formatDate(doc.bast_date, true))}. Yang bertanda tangan dibawah ini yaitu:</p>
          <table class="party-table"><tbody>
            <tr class="emphasis"><td>Pihak Pertama</td><td>:</td><td>${escapeHtml(doc.party_one?.company)}</td></tr>
            <tr><td>Diwakili oleh</td><td>:</td><td>${escapeHtml(doc.party_one?.name)}</td></tr>
            <tr><td>Jabatan</td><td>:</td><td>${escapeHtml(doc.party_one?.position)}</td></tr>
            <tr class="party-gap"><td colspan="3"></td></tr>
            <tr class="emphasis"><td>Pihak Kedua</td><td>:</td><td>${escapeHtml(doc.party_two?.company)}</td></tr>
            <tr><td>Diwakili oleh</td><td>:</td><td>${escapeHtml(doc.party_two?.name)}</td></tr>
            <tr><td>Jabatan</td><td>:</td><td>${escapeHtml(doc.party_two?.position)}</td></tr>
          </tbody></table>
          <p class="legal-text">Menyatakan bahwa kedua belah pihak telah melakukan serah terima material perangkat yang diserah terimakan dari PIHAK PERTAMA kepada PIHAK KEDUA, dengan rincian material pada lampiran dihalaman berikut.</p>
          <p class="legal-text">Apabila selama dalam masa pemakaian yang akan dilakukan PIHAK KEDUA terjadi kerusakan dan kehilangan maka hal tersebut akan menjadi tanggung jawab PIHAK KEDUA. Demikian berita acara serah terima ini dibuat dengan sebenar-benarnya sehingga bagi pihak bersangkutan yaitu PIHAK PERTAMA dan PIHAK KEDUA dapat menggunakan sebagaimana mestinya.</p>
          <p class="place-date">Palangka Raya, ${escapeHtml(formatDate(doc.bast_date))}</p>
          <div class="signature-row"><div><span>Security,</span><i></i><strong>(${escapeHtml(doc.signatures?.security)})</strong></div><div><span>Yang Menerima,</span><i></i><strong>(${escapeHtml(doc.signatures?.receiver)})</strong></div><div><span>Yang Menyerahkan,</span><i></i><strong>(${escapeHtml(doc.signatures?.sender)})</strong></div></div>
        </div>
      </article>
      <article class="paper print-page-2">
        <img class="paper-background" src="${background}" alt="">
        <div class="paper-content page-two-content"><h2 class="attachment-title">Lampiran</h2><table class="print-material-table"><colgroup><col style="width:9%"><col style="width:19%"><col style="width:28%"><col style="width:9%"><col style="width:19%"><col style="width:16%"></colgroup><thead><tr><th>No</th><th>KODE MATERIAL</th><th>NAMA BARANG</th><th>QTY</th><th>SN</th><th>KET</th></tr></thead><tbody>${materials}</tbody></table></div>
      </article>`;
  };

  // Fungsi cetak: buka PDF dari pdf.php pada tab Chrome baru.
  const printDocument = (doc) => {
    const pdfUrl = `pdf.php?id=${encodeURIComponent(doc.id)}`;
    const pdfTab = window.open(pdfUrl, '_blank');

    if (!pdfTab) {
      showAlert(
        'Tab PDF diblokir browser. Izinkan pop-up, lalu klik Cetak PDF lagi.',
        'error'
      );
    }
  };

  const collectForm = () => ({
    id: $('#document-id').value,
    date_mode: $('#date-mode').value,
    bast_date: $('#bast-date').value,
    number_mode: $('#number-mode').value,
    bast_number: $('#bast-number').value,
    party_one: { company: $('#p1-company').value, name: $('#p1-name').value, position: $('#p1-position').value },
    party_two: { company: $('#p2-company').value, name: $('#p2-name').value, position: $('#p2-position').value },
    signatures: { security: $('#signature-security').value, receiver: $('#signature-receiver').value, sender: $('#signature-sender').value },
    materials: $$('.material-row', $('#material-body')).map((row, index) => ({
      no: $('[data-material="no"]', row).value || String(index + 1),
      code: $('[data-material="code"]', row).value,
      name: $('[data-material="name"]', row).value,
      qty: $('[data-material="qty"]', row).value,
      sn: $('[data-material="sn"]', row).value,
      note: $('[data-material="note"]', row).value,
    })),
  });

  const findDoc = (id) => state.documents.find((doc) => String(doc.id) === String(id));

  document.addEventListener('click', async (event) => {
    const nav = event.target.closest('[data-view]');
    if (nav) {
      if (nav.dataset.view === 'form') openNewForm();
      else setView(nav.dataset.view);
      return;
    }

    const actionButton = event.target.closest('[data-action]');
    if (actionButton) {
      const { action, id } = actionButton.dataset;
      if (action === 'remove-row') {
        if ($$('.material-row', $('#material-body')).length <= 1) {
          showAlert('Minimal satu baris material harus ada.', 'error');
          return;
        }
        actionButton.closest('tr').remove();
        renumberMaterials();
        return;
      }
      const doc = findDoc(id);
      if (!doc) { showAlert('Dokumen tidak ditemukan. Muat ulang riwayat.', 'error'); return; }
      if (action === 'detail') openDetail(doc);
      if (action === 'edit') openEditForm(doc, 'history');
      if (action === 'print') printDocument(doc);
      return;
    }
  });

  $('#new-bast-button').addEventListener('click', openNewForm);
  $('#add-material').addEventListener('click', () => addMaterialRow());
  $('#date-mode').addEventListener('change', setDateMode);
  $('#bast-date').addEventListener('change', updateAutoNumberMessage);
  $('#number-mode').addEventListener('change', () => setNumberMode(false));
  $('#material-body').addEventListener('input', (event) => {
    if (event.target.matches('[data-material="no"]')) event.target.dataset.manualEdited = '1';
  });
  $('#history-search').addEventListener('input', renderHistory);
  $('#cancel-form').addEventListener('click', () => {
    if (state.returnAfterCancel === 'detail' && state.currentDocument) renderDetail(state.currentDocument);
    else setView('history');
  });
  $('#back-history').addEventListener('click', () => setView('history'));
  $('#edit-document').addEventListener('click', () => {
    if (state.currentDocument) openEditForm(state.currentDocument, 'detail');
  });
  $('#print-document').addEventListener('click', () => {
    if (state.currentDocument) printDocument(state.currentDocument);
  });
  $('#sync-document').addEventListener('click', async () => {
    if (!state.currentDocument) return;
    const button = $('#sync-document');
    button.disabled = true;
    button.textContent = 'Menyinkronkan...';
    try {
      const prepared = await api('sync', {
        method: 'POST',
        query: `&id=${encodeURIComponent(state.currentDocument.id)}`,
        body: {},
      });
      const result = await googleSheetsJsonp(prepared.bridge);
      showAlert(result.message || 'BAST berhasil disinkronkan ke Google Sheets.');
    } catch (error) {
      showAlert(`Sinkronisasi gagal: ${error.message}`, 'error');
    } finally {
      button.disabled = false;
      button.textContent = 'Sinkronkan';
    }
  });

  $('#bast-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!$('#bast-form').reportValidity()) return;
    const button = $('#save-button');
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = 'Menyimpan...';
    try {
      const formData = collectForm();
      const currentExisting = formData.id ? findDoc(formData.id) : null;
      let sequenceWarning = '';

      // Cek nomor terakhir di Google Sheets langsung dari browser.
      // Bila Google sementara tidak tersedia, penyimpanan lokal tetap berjalan.
      const needsRemoteSequence = formData.number_mode === 'auto' &&
        (!currentExisting || formData.bast_date !== String(currentExisting.bast_date || ''));
      if (needsRemoteSequence) {
        try {
          formData.external_max_sequence = await getGoogleMaxSequence(formData.bast_date);
        } catch (sequenceError) {
          formData.external_max_sequence = null;
          sequenceWarning = ` Nomor urut Google Sheets tidak dapat diperiksa (${sequenceError.message}); periksa nomor sebelum digunakan.`;
        }
      }

      const result = await api('save', { method: 'POST', body: formData });
      await refreshDocuments();
      state.currentDocument = result.document;
      renderDetail(result.document);

      if (result.bridge) {
        try {
          const synced = await googleSheetsJsonp(result.bridge);
          const syncMessage = synced.message || 'sinkronisasi Google Sheets berhasil';
          if (sequenceWarning) {
            showAlert(`BAST ${result.document.bast_number} tersimpan dan tersinkron;${sequenceWarning}`, 'error');
          } else {
            showAlert(`BAST ${result.document.bast_number} berhasil disimpan dan disinkronkan ke Google Sheets.`, 'success');
          }
        } catch (syncError) {
          showAlert(`BAST ${result.document.bast_number} tersimpan di hosting, tetapi sinkronisasi Google Sheets gagal: ${syncError.message}${sequenceWarning}`, 'error');
        }
      } else {
        showAlert(`BAST ${result.document.bast_number} tersimpan di hosting. Google Sheets belum dikonfigurasi.${sequenceWarning}`, 'error');
      }
    } catch (error) {
      showAlert(error.message, 'error');
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  });

  $('#today-label').textContent = formatDate(localToday());
  resetForm();
  refreshDocuments().catch((error) => showAlert(error.message, 'error'));
})();
